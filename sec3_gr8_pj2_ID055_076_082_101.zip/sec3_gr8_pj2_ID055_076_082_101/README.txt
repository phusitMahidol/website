We are sorry to say that we haven't finished the project on time
html and css are fine but js isn't finish.