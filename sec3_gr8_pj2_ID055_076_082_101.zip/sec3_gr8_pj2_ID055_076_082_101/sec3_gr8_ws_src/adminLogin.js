const admin = require('AdminLogin.js');

const connection = admin.createConnection({
  user: 'username',
  password: 'password',
  email: 'email',
  mobile: 'mobile'
});

connection.connect((err) => {
  if (err) {
    console.error('Invalid username or password', err);
    return;
  }

  console.log('Authentication successful');
});

app.listen(3000, () => {
  console.log('Server running on port 3000');
});

  