from flask import Flask, request, render_template
from elasticsearch import Elasticsearch
import math
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

ELASTIC_PASSWORD = "aon51904"

es = Elasticsearch("https://localhost:9200", http_auth=("elastic", ELASTIC_PASSWORD), verify_certs=False)
app = Flask(__name__, template_folder='templates', static_folder='static')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search')
def search():
    page_size = 10
    keyword = request.args.get('keyword')
    if request.args.get('page'):
        page_no = int(request.args.get('page'))
    else:
        page_no = 1

    body = {
    'size': page_size,
    'from': page_size * (page_no - 1),
    'query': {
        'multi_match': {
            'query': keyword,
            'fields': ['Name', 'Surname', 'Profile'],
            'type': 'best_fields',
            'fuzziness': 'AUTO',
        },

    },
    'sort': [
        '_score',
        {
            'Name.keyword': {
                'order': 'asc', 
                'mode': 'min',
                'unmapped_type': 'keyword',
            },
        },
        {
            'Surname.keyword': {
                'order': 'asc', 
                'mode': 'min',
                'unmapped_type': 'keyword',
            },
        },
    ],
    }

    res = es.search(index='fwpicture', body=body)
    grouped_hits = {}
    for doc in res['hits']['hits']:
        player_name = doc['_source'].get('Name')
        player_surname = doc['_source'].get('Surname')
        if player_name and player_surname:
            player_key = (player_name, player_surname)
            if player_key not in grouped_hits:
                grouped_hits[player_key] = {
                    'No': doc['_source'].get('No', None),
                    'Picture Link': doc['_source'].get('picture_link', []),
                    'Name': player_name,
                    'Surname': player_surname,
                    'Team': doc['_source'].get('Team', None),
                    'League': doc['_source'].get('League', None),
                    'Appearance': doc['_source'].get('Appearance (2022-2023)', None),
                    'Goal': doc['_source'].get('Goal (2022-2023)', None),
                    'Assist': doc['_source'].get('Assist (2022-2023)', None),
                    'WorldCupTrophy': doc['_source'].get('WorldCupTrophy', None),
                    'UCLTrophy': doc['_source'].get('UCLTrophy', None),
                    'Ballondor': doc['_source'].get("Ballond'or", None),
                    'GoldenBoot': doc['_source'].get('GoldenBoot', None),
                    'NationalTrophy': doc['_source'].get('NationalTrophy', None),
                    'Profile': doc['_source'].get('Profile', None),
                }

    hits = list(grouped_hits.values())

    page_total = math.ceil(res['hits']['total']['value'] / page_size)

    return render_template('search.html', keyword=keyword, hits=hits, page_no=page_no, page_total=page_total)